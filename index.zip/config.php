<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'pd_db');
define('GOOGLE_CLIENT_ID', '166518991572-8nro0tvfi0aj9t6mor39j5q2gt8cq8c7.apps.googleusercontent.com');
// LinkedIn API configuration
define('LIN_CLIENT_ID', '77sbv9sjri27u6');
define('LIN_CLIENT_SECRET', 'pwBB6pe3bGxNGndI');
define("LIN_SCOPE", 'r_liteprofile r_emailaddress' );
define('LIN_REDIRECT_URL',(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/project/login.php?linkedin");

// GIT API configuration
define('GIT_CLIENT_ID', '26b1bce81cabfc302ec8');
define('GIT_CLIENT_SECRET', '2957a6c578509e7094404283c64ec6accd3de867');
define("GIT_SCOPE", 'user:email' );
define('GIT_REDIRECT_URL',(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/project/login.php?git");

define('BASE_URL',(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/project/login.php");
/* Attempt to connect to MySQL database */
$con = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


?>