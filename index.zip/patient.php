
<h4>Parkinson’s Disease Exercises: Posture<h4>
<iframe width="560" height="315" src="https://www.youtube.com/embed/WRyPQO_u_qE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<h4>Parkinson’s Disease Exercises: Leg Strength</h4>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/Gh8cZ_W2vR4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<h4>Parkinson's Disease Exercises: Brain and Body</h4>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/pWqext64kxM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
